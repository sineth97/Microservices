package com.sliit.paf.payment.repository.custom;


import com.sliit.paf.payment.entity.Item;
import com.sliit.paf.payment.repository.CrudRepository;

public interface ItemRepository extends CrudRepository<Item, String> {

}
