package com.sliit.paf.payment.entity;

public class SuperEntity{
}
