package com.sliit.paf.payment.repository.custom;

import com.sliit.paf.payment.entity.Customer;
import com.sliit.paf.payment.repository.CrudRepository;


public interface CustomerRepository extends CrudRepository<Customer, String> {

}
