package com.sliit.paf.payment.service;

public interface SuperService {
}
