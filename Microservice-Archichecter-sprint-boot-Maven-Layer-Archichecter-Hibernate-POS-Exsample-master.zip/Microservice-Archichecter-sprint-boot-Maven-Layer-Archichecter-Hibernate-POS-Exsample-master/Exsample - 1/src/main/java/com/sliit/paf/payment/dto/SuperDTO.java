package com.sliit.paf.payment.dto;

public abstract class SuperDTO {
}
